from django.db import models

# Create your models here.
# creating model i.e table
# table name should be same as model name

class msg(models.Model):
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    mobile = models.BigIntegerField()
    msg = models.CharField(max_length=200)