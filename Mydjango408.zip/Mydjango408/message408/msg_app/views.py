from django.http import HttpResponse
from django.shortcuts import redirect, render
from msg_app.models import msg


# Create your views here.
def home(request):
    return HttpResponse("hello succesful")
       
def create(request):
    print("request is : "+request.method)
    if request.method == 'POST' :
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        message = request.POST['message']
        print(name ,email ,mobile ,message)
        
        m=msg.objects.create(name=name, email=email , mobile=mobile , msg=message)
        m=msg.objects.all()
        # m.save()
        print(m)
        # return HttpResponse("Data added successfully !!")
        return redirect("/dashboard")
    else:
        return render(request,'create.html')

def dashboard(request):
    m = msg.objects.all()
    print(m)
    context={}
    context['data']=m
    return render(request, 'dashboard.html',context)
    # return HttpResponse("dashboard is here...")
    
def edit(request,rid):
    if request.method =='POST':
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        message = request.POST['message']
        m=msg.objects.filter(id=rid)
        m.update(name=name, email=email , mobile=mobile , msg=message)
        return redirect('/dashboard')
    else:
        m=msg.objects.get(id=rid)
        context={}
        context['data']=m
        return render(request,'edit.html',context)
    
    return redirect('/dashboard')
    # print("id to be edited..",rid)
    # return HttpResponse("id to be edited.."+rid)

def delete(request,rid):
    
    m=msg.objects.filter(id=rid)
    m.delete()
    return redirect('/dashboard')
    # print("id to be deleted..",rid)
    # return HttpResponse("id to be deleted.."+rid)
