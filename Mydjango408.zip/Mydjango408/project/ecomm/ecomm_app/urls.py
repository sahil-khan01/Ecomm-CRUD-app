from ecomm import settings
from django.conf.urls.static import static
from django.urls import path
from ecomm_app import views

urlpatterns = [
    # path('about/',views.about),
    # path('home/',views.home),
    # path('edit/<sid>',views.edit),
    # path('myview/',views.simpleview.as_view()),
    # path('hello/',views.hello),
    
    path('index/',views.index),
    path('',views.index),
    path('product/<pid>',views.product_page),
    path('addtocart/<pid>',views.addtocart),
    path('cart/',views.viewcart),
    path('updateqty/<qv>/<id>',views.updateqty),
    path('remove/<id>',views.remove),
    path('placeorder/',views.placeorder),
    path('makepayment/',views.makepayment),
    path('register/',views.register),
    path('login/',views.userlogin),
    path('logout/',views.userlogout),
    path('catfilter/<cv>',views.catfilter),
    path('sort/<sv>',views.sort),
    path('range/',views.range),
    # path('rangeprice/',views.rangeprice),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)