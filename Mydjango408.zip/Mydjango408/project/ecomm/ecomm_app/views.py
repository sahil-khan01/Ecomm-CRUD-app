from random import randrange
from django.shortcuts import redirect, render,HttpResponse
from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from ecomm_app.models import *
from django.db.models import Q
import razorpay

# Create your views here.
# def about(request):
#     return HttpResponse("This is About Page....")

# def home(request):
#     return HttpResponse("<h1>hello Heading</h1>")

# def edit(request,sid):
#     return HttpResponse("to edit id: "+sid)

# def hello(request):
#     context={}
#     context['greet']="good evening,we are learning DTL..."
#     context['x']=40
#     context['y']=20
    
#     context['li']=[10,20,30,40,50]
    
#     context['products']=[{'id':1,'name':'iphone','price':2000},
#                          {'id':2,'name':'LG','price':5000}]
#     return render(request,'hello.html',context)
    
    
# class simpleview(View):
#     def get(self,request):
#         return HttpResponse("This is simple view..")

# def rangeprice(request):
#     if request.method == 'POST':
#         minval = request.POST['min']
#         maxval = request.POST['max']
#         context={}
#         p=product.objects.filter('price'>=minval & 'price'<= maxval ).order_by('price')
#         context['products']=p
#         return render(request,'index.html',context)
    # else:
    #     return render(request,'index.html',context)

def range(request):
    min=request.GET.get('min')   
    max=request.GET.get('max')    
    q1=Q(price__gte=min) 
    q2=Q(price__lte=max)
    q3=Q(is_active=True)
    p=product.objects.filter(q1 & q2 & q3) 
    context={}
    context['products']=p
    return render(request,'index.html',context)
    
def index(request):
    userid=request.user.id
    print(userid)
    print(request.user.is_authenticated)
    context={}
    p=product.objects.filter(is_active=True)
    context['products']=p
    # print(p)   
    return render(request,'index.html',context)
    
def catfilter(request,cv):
    q1=Q(is_active=True)
    q2=Q(category=cv)
    context={}
    p=product.objects.filter(q1 & q2)
    context['products']=p
    return render(request,'index.html',context)

def sort(request,sv):
    if sv == '1':
        col='price'
    elif sv == '0':
        col='-price'
    context={}
    p=product.objects.filter(is_active =True).order_by(col)
    context['products']=p
    return render(request,'index.html',context)
    

def product_page(request,pid):
    p=product.objects.filter(id=pid)
    context={}
    context['products']=p
    return render(request,'product.html',context)

def viewcart(request):
    userid=request.user.id
    c=cart.objects.filter(uid=userid)
    s=0
    n=len(c)
    context={}
    for x in c:
        print(x)
        print(x.pid.price)
        s=s+(x.pid.price * x.qty)
    # print(s)
    context['products']=c
    context['total']=s
    context['noofitems']=n
    return render(request,'cart.html',context)

def updateqty(request,qv,id):
    c=cart.objects.filter(id=id)
    print(c)  # object queryset
    print(c[0])  # object 
    print(c[0].qty)
    if qv == '1':
        t=c[0].qty+1
        c.update(qty=t)
    else:
        if c[0].qty > 1:
            t=c[0].qty-1
            c.update(qty=t)
    return redirect('/cart/')
    
    

def remove(request,id):
    c=cart.objects.filter(id=id)
    c.delete()
    return redirect('/cart/')
    

def addtocart(request,pid):
    if request.user.is_authenticated:
        userid=request.user.id
        print(pid)
        print(userid)
        u=User.objects.filter(id=userid)
        print(u[0])
        print(u)
        p=product.objects.filter(id=pid)
        print(p[0])
        print(p)
        q1=Q(uid=u[0])
        q2=Q(pid=p[0])
        c=cart.objects.filter(q1 & q2)
        n=len(c)
        context={}
        context['products']=p
        if n==1:
            context['msg']="Product already exist in cart..."
        else:
            c=cart.objects.create(uid=u[0],pid=p[0])
            c.save()
            # context={}
            # context['products']=p
            context['success']='product added successfully'
        return render(request,'addtocart.html',context)
    else:
        return redirect('/login')

def placeorder(request):
    userid=request.user.id
    print(userid)
    c=cart.objects.filter(uid=userid)
    #print(c)
    oid=randrange(1000,9999)
    print("order_id: ",oid)
    context={}
    for x in c:
        o=order.objects.create(oid=oid,uid=x.uid,pid=x.pid,qty=x.qty)
        o.save()
        # x.delete()     # to delete previus cart data
        # orders=order.objects.filter(uid=request.user.id)
        orders=order.objects.filter(oid=oid)
        # context={}
        context['products']=orders
        np=len(orders)
        s=0
        for x in orders:
            s=s+x.pid.price*x.qty
         
        context['total']=s
        context['n']=np    
    return render(request,'placeorder.html',context)

def makepayment(request):
# key_id,key_secret
# rzp_test_UzHoCXEojRyOKT,Fly7qbELMMjLxHvRZPnxGBVL
    orders=order.objects.filter(uid=request.user.id)
    s=0
    for x in orders:
        s=s+x.pid.price * x.qty
        print(s)
        
    client = razorpay.Client(auth=("rzp_test_UzHoCXEojRyOKT", "Fly7qbELMMjLxHvRZPnxGBVL"))
    data = { "amount": s*100, "currency": "INR", "receipt": "id" }
    payment = client.order.create(data=data)
    print(payment)
    context={}
    context['data']=payment
    return render(request,'pay.html',context)

def vieworder(request):
    return render(request,'order.html')

def register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        upass = request.POST['upass']
        cpass = request.POST['cpass']
        
        context={}
        if name =="" or email == "" or upass =="" or cpass=="":
            context["errmsg"] = "This field is empty"
            return render(request,'register.html',context)

        elif upass != cpass:
            context['errmsg'] = "password incorrect. Didn't match"
            return render(request,'register.html',context)
         
        else: 
            try:   
                u=User.objects.create(password=upass,username=name,email=email)
                u.set_password(upass)   # encrypted format
                u.save()
                context["success"]="User created successfully"
                return render(request,'register.html',context)
            except Exception:
                context['errmsg']="User alreadry exists... duplicate entry"
                return render(request,'register.html',context)

                
        # return HttpResponse("data fetched...")
    
    else:
        return render(request,'register.html')
        
        
def userlogin(request):
    if request.method == 'POST':
        name = request.POST['name']
        upass = request.POST['pass']
        context={}
        if  name == "" or upass =="" :
            context["errmsg"] = "This field is empty"
            return render(request,'login.html',context)
        else:
            u=authenticate(username=name,password=upass)
            if u is not None:
                login(request,u)
                return redirect("/index/")
            else:
                context["errmsg"] = "Invalid credentials..."
                return render(request,'login.html',context)
            
    else:
        return render(request,'login.html')

def userlogout(request):
    logout(request)
    return redirect('/login/')
