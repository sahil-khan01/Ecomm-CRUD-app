from django.contrib import admin
from ecomm_app.models import product



class productadmin(admin.ModelAdmin):
    list_display=['id','name','price','category','is_active']
    list_filter=['category','is_active']
    
# Register your models here.
admin.site.register(product)
